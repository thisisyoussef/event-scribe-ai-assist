// Comprehensive debug script for volunteer removal and contact cleanup
// Run this in your browser console

async function debugVolunteerRemoval() {
  console.log('=== COMPREHENSIVE VOLUNTEER REMOVAL DEBUG ===');
  
  try {
    // 1. Get all volunteers
    const { data: volunteers, error: volunteerError } = await supabase
      .from('volunteers')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (volunteerError) {
      console.error('Error fetching volunteers:', volunteerError);
      return;
    }
    
    console.log('📋 Current volunteers:', volunteers);
    
    // 2. Get all contacts
    const { data: contacts, error: contactError } = await supabase
      .from('contacts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (contactError) {
      console.error('Error fetching contacts:', contactError);
      return;
    }
    
    console.log('👥 Current contacts:', contacts);
    
    // 3. Get all volunteer signups
    const { data: signups, error: signupError } = await supabase
      .from('volunteer_signups')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (signupError) {
      console.error('Error fetching volunteer signups:', signupError);
      return;
    }
    
    console.log('📝 Current volunteer signups:', signups);
    
    // 4. Check for orphaned data
    console.log('\n🔍 CHECKING FOR ORPHANED DATA:');
    
    // Volunteers without corresponding contacts
    const volunteersWithoutContacts = volunteers.filter(volunteer => {
      return !contacts.some(contact => 
        contact.name === volunteer.name && contact.phone === volunteer.phone
      );
    });
    
    if (volunteersWithoutContacts.length > 0) {
      console.warn('⚠️ Volunteers without corresponding contacts:', volunteersWithoutContacts);
    } else {
      console.log('✅ All volunteers have corresponding contacts');
    }
    
    // Contacts without corresponding volunteers (but with volunteer signups)
    const contactsWithoutVolunteers = contacts.filter(contact => {
      const hasVolunteer = volunteers.some(volunteer => 
        volunteer.name === contact.name && volunteer.phone === contact.phone
      );
      const hasSignups = signups.some(signup => signup.contact_id === contact.id);
      return !hasVolunteer && hasSignups;
    });
    
    if (contactsWithoutVolunteers.length > 0) {
      console.warn('⚠️ Contacts with signups but no corresponding volunteers:', contactsWithoutVolunteers);
    } else {
      console.log('✅ All contacts with signups have corresponding volunteers');
    }
    
    // Orphaned volunteer signups (signups without corresponding volunteers)
    const orphanedSignups = signups.filter(signup => {
      const contact = contacts.find(c => c.id === signup.contact_id);
      if (!contact) return true;
      
      return !volunteers.some(volunteer => 
        volunteer.name === contact.name && volunteer.phone === contact.phone
      );
    });
    
    if (orphanedSignups.length > 0) {
      console.warn('⚠️ Orphaned volunteer signups (should be cleaned up):', orphanedSignups);
    } else {
      console.log('✅ No orphaned volunteer signups found');
    }
    
    // 5. Test specific contact filtering
    console.log('\n🎯 TESTING CONTACT FILTERING:');
    
    // Simulate the contacts filtering logic
    const testContact = contacts[0];
    if (testContact) {
      console.log('Testing contact:', testContact.name);
      
      // Load volunteer history for this contact
      const { data: contactSignups, error: contactSignupError } = await supabase
        .from('volunteer_signups')
        .select(`
          event_id,
          role_id,
          signup_date,
          status
        `)
        .eq('contact_id', testContact.id)
        .order('signup_date', { ascending: false });
      
      if (contactSignupError) {
        console.error('Error loading signups for test contact:', contactSignupError);
      } else {
        console.log('Volunteer signups for test contact:', contactSignups);
        
        // Load event and role details
        if (contactSignups && contactSignups.length > 0) {
          const signupDetails = await Promise.all(
            contactSignups.map(async (signup) => {
              const { data: event } = await supabase
                .from('events')
                .select('id, title, start_datetime')
                .eq('id', signup.event_id)
                .is('deleted_at', null)
                .single();

              const { data: role } = await supabase
                .from('volunteer_roles')
                .select('id, role_label')
                .eq('id', signup.role_id)
                .single();

              if (event && role) {
                return {
                  event,
                  role,
                  signup_date: signup.signup_date,
                  status: signup.status,
                };
              }
              return null;
            })
          );
          
          const validSignups = signupDetails.filter(signup => signup !== null);
          console.log('Valid volunteer history for test contact:', validSignups);
        }
      }
    }
    
  } catch (error) {
    console.error('Error in debug script:', error);
  }
}

// Instructions
console.log(`
=== VOLUNTEER REMOVAL DEBUG INSTRUCTIONS ===

1. Run this script to see current state: debugVolunteerRemoval()

2. To test volunteer removal:
   - Go to a volunteer signup page
   - Find a volunteer and click the remove button
   - Complete the removal process
   - Watch the browser console for deletion logs

3. Run this script again to verify:
   - The volunteer should be removed from volunteers table
   - The volunteer_signups record should be removed
   - If the contact was created from volunteer signup and has no other signups, it should be removed from contacts table

4. Check the browser console for detailed logs from the Edge Function
`);

// Run the debug
debugVolunteerRemoval();

