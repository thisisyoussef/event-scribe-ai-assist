// Test script to verify volunteer removal and contact cleanup
// Run this in your browser console on the volunteer signup page

async function testVolunteerRemovalCleanup() {
  console.log('=== TESTING VOLUNTEER REMOVAL AND CONTACT CLEANUP ===');
  
  try {
    // Get recent volunteers
    const { data: volunteers, error: volunteerError } = await supabase
      .from('volunteers')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);
    
    if (volunteerError) {
      console.error('Error fetching volunteers:', volunteerError);
      return;
    }
    
    console.log('Recent volunteers:', volunteers);
    
    // Get contacts with volunteer_signup source
    const { data: volunteerContacts, error: contactError } = await supabase
      .from('contacts')
      .select('*')
      .eq('source', 'volunteer_signup')
      .order('created_at', { ascending: false })
      .limit(5);
    
    if (contactError) {
      console.error('Error fetching volunteer contacts:', contactError);
      return;
    }
    
    console.log('Contacts with volunteer_signup source:', volunteerContacts);
    
    // Get volunteer signups
    const { data: signups, error: signupError } = await supabase
      .from('volunteer_signups')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);
    
    if (signupError) {
      console.error('Error fetching volunteer signups:', signupError);
      return;
    }
    
    console.log('Recent volunteer signups:', signups);
    
    // Check for orphaned contacts (contacts with volunteer_signup source but no signups)
    const orphanedContacts = volunteerContacts.filter(contact => {
      return !signups.some(signup => signup.contact_id === contact.id);
    });
    
    if (orphanedContacts.length > 0) {
      console.warn('Found orphaned contacts (should be cleaned up):', orphanedContacts);
    } else {
      console.log('✅ No orphaned contacts found');
    }
    
    // Check for volunteers without corresponding contacts
    const volunteersWithoutContacts = volunteers.filter(volunteer => {
      return !volunteerContacts.some(contact => 
        contact.name === volunteer.name && contact.phone === volunteer.phone
      );
    });
    
    if (volunteersWithoutContacts.length > 0) {
      console.warn('Found volunteers without corresponding contacts:', volunteersWithoutContacts);
    } else {
      console.log('✅ All volunteers have corresponding contacts');
    }
    
  } catch (error) {
    console.error('Error in test script:', error);
  }
}

// Instructions for testing
console.log(`
=== VOLUNTEER REMOVAL TEST INSTRUCTIONS ===

1. Run this script to see current state: testVolunteerRemovalCleanup()

2. To test volunteer removal:
   - Go to a volunteer signup page
   - Find a volunteer and click the remove button
   - Choose either phone verification or admin password
   - Complete the removal process

3. Run the script again to verify:
   - The volunteer is removed from volunteers table
   - The volunteer_signups record is removed
   - If the contact was created from volunteer signup and has no other signups, it should be removed from contacts table
   - If the contact has other signups or was created manually, it should remain

4. Check the browser console for detailed deletion logs
`);

// Run the test
testVolunteerRemovalCleanup();

