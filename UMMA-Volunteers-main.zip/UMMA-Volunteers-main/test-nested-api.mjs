// Nested embed test mirroring Dashboard query
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://spkbyweazhaxjwnokugj.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNwa2J5d2VhemhheGp3bm9rdWdqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkxMDAyMTEsImV4cCI6MjA2NDY3NjIxMX0.h68BX9j0jyi7zAS5AXmVnq8iLqfz0gCX-SUTKMFpSMU';

const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

async function run() {
  console.log('🧪 Testing nested select on events with embeddings...');
  const { data, error } = await supabase
    .from('events')
    .select(`*, volunteer_roles(*), volunteers(*)`)
    .is('deleted_at', null)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('❌ Error:', error);
  } else {
    console.log('✅ Success. Rows:', data?.length ?? 0);
  }
}

run().catch((e) => console.error(e));


