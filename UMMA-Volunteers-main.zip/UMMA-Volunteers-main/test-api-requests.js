// Test script to verify API requests are working after RLS fix
// Run this with: node test-api-requests.js

import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = "https://spkbyweazhaxjwnokugj.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNwa2J5d2VhemhheGp3bm9rdWdqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkxMDAyMTEsImV4cCI6MjA2NDY3NjIxMX0.h68BX9j0jyi7zAS5AXmVnq8iLqfz0gCX-SUTKMFpSMU";

const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

async function testAPIRequests() {
  console.log('🧪 Testing API requests after RLS fix...\n');

  try {
    // Test 1: Check authentication
    console.log('1. Testing authentication...');
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError) {
      console.log('❌ Authentication error:', authError.message);
      console.log('   Note: You need to be logged in to test these requests');
      return;
    }
    console.log('✅ Authentication successful');

    // Test 2: Load events
    console.log('\n2. Testing events loading...');
    const { data: events, error: eventsError } = await supabase
      .from('events')
      .select(`
        *,
        volunteer_roles(*),
        volunteers(*)
      `)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (eventsError) {
      console.log('❌ Events loading error:', eventsError.message);
      console.log('   Error code:', eventsError.code);
      console.log('   Error details:', eventsError.details);
    } else {
      console.log('✅ Events loaded successfully');
      console.log(`   Found ${events?.length || 0} events`);
    }

    // Test 3: Load contacts
    console.log('\n3. Testing contacts loading...');
    const { data: contacts, error: contactsError } = await supabase
      .from('contacts')
      .select('*')
      .order('created_at', { ascending: false });

    if (contactsError) {
      console.log('❌ Contacts loading error:', contactsError.message);
      console.log('   Error code:', contactsError.code);
      console.log('   Error details:', contactsError.details);
    } else {
      console.log('✅ Contacts loaded successfully');
      console.log(`   Found ${contacts?.length || 0} contacts`);
    }

    // Test 4: Load volunteer roles
    console.log('\n4. Testing volunteer roles loading...');
    const { data: roles, error: rolesError } = await supabase
      .from('volunteer_roles')
      .select('*')
      .limit(10);

    if (rolesError) {
      console.log('❌ Volunteer roles loading error:', rolesError.message);
      console.log('   Error code:', rolesError.code);
      console.log('   Error details:', rolesError.details);
    } else {
      console.log('✅ Volunteer roles loaded successfully');
      console.log(`   Found ${roles?.length || 0} volunteer roles`);
    }

    // Test 5: Load volunteers
    console.log('\n5. Testing volunteers loading...');
    const { data: volunteers, error: volunteersError } = await supabase
      .from('volunteers')
      .select('*')
      .limit(10);

    if (volunteersError) {
      console.log('❌ Volunteers loading error:', volunteersError.message);
      console.log('   Error code:', volunteersError.code);
      console.log('   Error details:', volunteersError.details);
    } else {
      console.log('✅ Volunteers loaded successfully');
      console.log(`   Found ${volunteers?.length || 0} volunteers`);
    }

    console.log('\n🎉 API testing completed!');
    console.log('\nIf you see any 406 errors, the RLS policies may need further adjustment.');
    console.log('If all tests pass, the 406 errors should be resolved in your application.');

  } catch (error) {
    console.error('❌ Unexpected error during testing:', error);
  }
}

// Run the tests
testAPIRequests();
