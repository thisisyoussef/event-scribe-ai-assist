// Simple API test without authentication
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = "https://spkbyweazhaxjwnokugj.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNwa2J5d2VhemhheGp3bm9rdWdqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkxMDAyMTEsImV4cCI6MjA2NDY3NjIxMX0.h68BX9j0jyi7zAS5AXmVnq8iLqfz0gCX-SUTKMFpSMU";

const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

async function testSimpleAPI() {
  console.log('🧪 Testing simple API calls with RLS disabled...\n');

  try {
    // Test 1: Simple events query
    console.log('1. Testing events query...');
    const { data: events, error: eventsError } = await supabase
      .from('events')
      .select('id, title')
      .limit(5);

    if (eventsError) {
      console.log('❌ Events error:', eventsError.message);
      console.log('   Status:', eventsError.status);
      console.log('   Code:', eventsError.code);
    } else {
      console.log('✅ Events query successful');
      console.log(`   Found ${events?.length || 0} events`);
    }

    // Test 2: Simple contacts query
    console.log('\n2. Testing contacts query...');
    const { data: contacts, error: contactsError } = await supabase
      .from('contacts')
      .select('id, name')
      .limit(5);

    if (contactsError) {
      console.log('❌ Contacts error:', contactsError.message);
      console.log('   Status:', contactsError.status);
      console.log('   Code:', contactsError.code);
    } else {
      console.log('✅ Contacts query successful');
      console.log(`   Found ${contacts?.length || 0} contacts`);
    }

    console.log('\n🎉 Simple API test completed!');
    console.log('If both tests pass, the 406 errors should be resolved in your browser.');

  } catch (error) {
    console.error('❌ Unexpected error:', error);
  }
}

testSimpleAPI();
