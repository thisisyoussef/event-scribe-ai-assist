// Debug script to check contacts and volunteers
// Run this in your browser console on the volunteer signup page

async function debugContactsAndVolunteers() {
  console.log('=== DEBUGGING CONTACTS AND VOLUNTEERS ===');
  
  try {
    // Check recent volunteers
    const { data: volunteers, error: volunteerError } = await supabase
      .from('volunteers')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (volunteerError) {
      console.error('Error fetching volunteers:', volunteerError);
    } else {
      console.log('Recent volunteers:', volunteers);
    }
    
    // Check contacts with volunteer_signup source
    const { data: volunteerContacts, error: contactError } = await supabase
      .from('contacts')
      .select('*')
      .eq('source', 'volunteer_signup')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (contactError) {
      console.error('Error fetching volunteer contacts:', contactError);
    } else {
      console.log('Contacts with volunteer_signup source:', volunteerContacts);
    }
    
    // Check all contacts
    const { data: allContacts, error: allContactsError } = await supabase
      .from('contacts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (allContactsError) {
      console.error('Error fetching all contacts:', allContactsError);
    } else {
      console.log('All recent contacts:', allContacts);
    }
    
    // Check volunteer_signups table
    const { data: signups, error: signupError } = await supabase
      .from('volunteer_signups')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (signupError) {
      console.error('Error fetching volunteer signups:', signupError);
    } else {
      console.log('Recent volunteer signups:', signups);
    }
    
  } catch (error) {
    console.error('Error in debug script:', error);
  }
}

// Run the debug function
debugContactsAndVolunteers();

